import './App.css';
import './bootstrap.css'
import Navbar from './components/Navbar'
import Home from './components/Home';
import Signup from './components/Signup'
import Login from './components/Login'
import AboutUs from './components/AboutUs';
import ContactUS from './components/ContactUS'
import Errorpage from './components/Error404'
import {Route,Switch} from 'react-router-dom'

function App() {
  return (
    <div>
      <Navbar/>
        <Switch>
        <Route exact path="/">
          <Home/>
        </Route>
        <Route  path="/login">
          <Login/>
        </Route>
        <Route path="/signup">
          <Signup/>
        </Route>
        <Route  path="/aboutus">
          <AboutUs/>
        </Route>
        <Route path="/contactus">
          <ContactUS/>
        </Route>
        <Route>
          <Errorpage/>
        </Route>
        </Switch>
    </div>
  );
}

export default App;
