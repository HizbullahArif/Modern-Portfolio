import React,{useEffect} from 'react'
import hizb from '../images/hizb.png';
import {useHistory} from 'react-router-dom'

export default function AboutUs() {
  const history = useHistory()
   const callaboutpage = async ()=>{
        
        try{
          const res = await fetch('/about',{
          method:'GET',
          headers: {
            Accept: 'application/json',
            'Content-Type': 'application/json',
          },
          credentials:"include",
        });
        const data = res.json();
        if(!res.status === 200){
          
          const error = new Error(res.error)
          throw error;
          
        }
        
      }catch(err){
        console.log("Error About:"+err)
        history.push('/login');
      }
      
     }
  
  
  useEffect(()=>{
        callaboutpage();
    },[callaboutpage]);

    return (
        <>
          <div className="container mt-3 ">
          <div className="col-10 offset-1">
          <div className="card btn-outline-light ">
            <div className="row">
                <div className="col-4">
                    <img src={hizb} alt="hizbullah" style={{ width:"300px", height:"300px"}}/>
                    <h4  style={{textAlign:"center"}}>Web Developer</h4>
                </div>
                <div className="col-6" style={{textAlign:"center"}}>
                    <h1 className="mt-5">Hizbullah</h1>
                    <h5 >SOFTWARE ENGINEER</h5>
                    {/* Nav bar */}

                    <ul class="nav nav-tabs mt-5">
                        <li class="nav-item">
                            <a class="nav-link active" data-bs-toggle="tab" href="#home">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-bs-toggle="tab" href="#profile">Time Line</a>
                        </li>
                    </ul>
                    {/* Nav Bar end */}
                    <div className="row mt-4 mb-5" style={{textAlign:"left"}}>
                    <div className="col-3">
                      <h6>User ID</h6>
                      <h6>Name</h6>
                      <h6>Email</h6>
                      <h6>Phone</h6>
                      <h6>Profession</h6>
                    </div>
                    <div className="col-8">
                      <h6>12345678</h6>
                      <h6>Hizbullah</h6>
                      <h6>hizbullahkhan887@gmail.com</h6>
                      <h6>03410997887</h6>
                      <h6>WEB DEVELOPER</h6>
                    </div>
                    </div>
                </div>
                <div className="col-2 mt-4 ml-2 d-flex flex-column">
                <button type="button" class="btn btn-primary btn-sm ">Edit profile</button>
                </div>
            </div>
          </div>
          </div>
          </div>
        </>
    )
}
