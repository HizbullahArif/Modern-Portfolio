import {React,useState} from 'react'

export default function Login() {
    const [email,setEmail] = useState()
    const [password,setPassword]=useState()

    const LoginUser= async (e)=>{
        e.preventDefault();
        console.log(email,password)
        const res = await fetch('/signin',{
            method: 'POST',
            headers:{
                "Content-Type": "application/json"
            },
            body:JSON.stringify(
                {email,
                password
                })
        });
        const res2= await res.json();
        console.log(res2);
    }
    return (
        <>
            <div className="container mt-3 ">
            <div className="col-7 offset-3">
            <div className="card btn-outline-light border-primary mb-3">
            <div className="card-header"><h1>Login</h1></div>
            <div className="card-body">
                <form method="POST">
                    <div className="form-group">
                    <label htmlFor="exampleInputEmail1" className="form-label">Email address</label>
                    <input type="email" className="form-control" id="exampleInputEmail1"  placeholder="Enter email" value={email} onChange={(e)=>{setEmail(e.target.value)}}/>
                    </div>

                    <div className="form-group">
                    <label htmlFor="exampleInputPassword1" className="form-label mt-2">Password</label>
                    <input type="password" name="password" className="form-control"  placeholder="Password" value={password} onChange={(e)=>{setPassword(e.target.value)}}/>
                    </div>

                    <button type="submit" className="btn btn-primary mt-2" onClick={LoginUser}>Submit</button>
            
                </form>

            </div>
            </div>
            </div>
            </div>
       </>
    )
}
