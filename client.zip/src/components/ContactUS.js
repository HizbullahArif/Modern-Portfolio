import React from 'react'

export default function ContactUS() {
    return (
        <>
        <div className="container mt-3 ">
        <div className="col-10 offset-1">
        <div className="card btn-outline-light mb-3">
        <div className="card-header"><h1>Get in Touch</h1></div>
        <div className="card-body">
        
            <form>
            <div className="row">
            <div className="col-4">
            <input type="email" name="email" className="form-control" placeholder="Email" />
            </div>
            <div className="col-4">
            <input type="email" name="name" className="form-control" placeholder="Name" />
            </div>
            <div className="col-4">
            <input type="email" name="phone" className="form-control" placeholder="Phone Number" />
            </div>
            </div>
                <div class="form-group">
                <label for="exampleTextarea" class="form-label mt-4">Enter your message</label>
                <textarea class="form-control" name="message" placeholder="your Message" rows="3"></textarea>
                </div>
            <button type="submit" className="btn btn-primary mt-2">Submit</button>
        
            </form>

        </div>
        </div>
        </div>
        </div>
   </>
    )
}
