import React from 'react'
import SignupForm from './SignupForm'
export default function Signup() {
    return (
       <>
            <div className="container mt-3 ">
            <div className="col-7 offset-3">
            <div className="card btn-outline-light border-primary mb-3">
            <div className="card-header"><h1>Sign Up</h1></div>
            <div className="card-body">
                <SignupForm/>
            </div>
            </div>
            </div>
            </div>
       </>
    )
}
