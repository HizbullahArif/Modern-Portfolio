import React from 'react'
import { useState} from 'react'
export default function SignupForm() {
    const [user,setUser] = useState({
        name1: '',email: '',phone: '',profession:'',password:'',cpassword:''
    });

    let name,value;
    const handleInput=(e)=> {
        // console.log(e)
        name= e.target.name;
        value= e.target.value;
        setUser({...user,[name]:value});
        // console.log(user)
    }

    const postData= async (e)=>{
        e.preventDefault();
        const {name1,email,phone,profession,password,cpassword}= user
        console.log(name1,email,phone,profession,password,cpassword)
        
        const res = await fetch('/register',{
            method: 'POST',
            headers: {'Content-Type':'application/json'},
            body: JSON.stringify({
                name1,email,phone,profession,password,cpassword
            })
        });
        
        const res2 = await res.json();
        console.log(res2)
        if(res2.status === 200){
            console.log('Data added Successfully');
        }
    }

    return (
        <div>
            <form method="POST" >
                <div className="form-group">
                <label htmlFor="Name" className="form-label">Your Name</label>
                <input type="text" name='name1' className="form-control" id="name" placeholder="Enter name" value={user.name1} onChange={handleInput}/>
                </div>

                <div className="form-group">
                <label htmlFor="exampleInputEmail1" className="form-label">Email address</label>
                <input type="email" name='email' className="form-control" id="exampleInputEmail1" value={user.email} onChange={handleInput} placeholder="Enter email" />
                </div>

                <div className="form-group">
                <label htmlFor="mobileNumber" className="form-label">Mobile Number</label>
                <input type="phone" name="phone" className="form-control" id="mobile Number" value={user.phone} onChange={handleInput} placeholder="Enter Mobile Number" />
                </div>

                <div className="form-group">
                <label htmlFor="profession" className="form-label">Your profession</label>
                <input type="text" name='profession' className="form-control" id="profession" value={user.profession} onChange={handleInput} placeholder="Enter profession" />
                </div>

                <div className="form-group">
                <label htmlFor="exampleInputPassword1" className="form-label mt-2">Password</label>
                <input type="password" name="password" className="form-control" value={user.password} onChange={handleInput}  placeholder="Password" />
                </div>

                <div className="form-group">
                <label htmlFor="exampleInputPassword1" className="form-label mt-2">Confirm Password</label>
                <input type="password" name="cpassword" className="form-control" value={user.cpassword} onChange={handleInput} placeholder="confirm Password" />
                </div>
                <button type="submit" className="btn btn-primary mt-2" onClick={postData}>Submit</button>            
        </form>
        </div>
    )
}
