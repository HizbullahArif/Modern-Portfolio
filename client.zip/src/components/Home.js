import React from 'react'

export default function Home() {
    return (
        <>
           <div className="container mt-5" >
            <div className="col-7 offset-2">
            <div className="card btn-outline-info " style={{marginTop:'30%'}}>
            <div className="card-body " style={{textAlign:'center'}}>
                <h1 >Welcome to MERN PROJECT</h1>
                <h2>By Hizbullah</h2>
            </div>
            </div>
            </div>
            </div>
        </>
    )
}