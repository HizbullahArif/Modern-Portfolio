import React from 'react'

export default function Error404() {
    return (
        <>
          <div style={{fontSize:'26px', textAlign:'center',marginTop:'16%'}}>
            <h1>404 Error</h1>
            <h1>Page Not found</h1>
          </div>
        </>
    )
}
